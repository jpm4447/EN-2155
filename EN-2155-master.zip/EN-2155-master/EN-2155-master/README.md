EN-2155
A small infinite runner

Post Version Notes Here
