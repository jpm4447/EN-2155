﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EN_ExternalTool
{

    // in this program:
    // 1 = platform
    // 0 = open air
    // G = ground
    // P = pit
    public partial class Form1 : Form
    {
        // attributes
        string name = "";
        string col1 = "";
        string col2 = "";
        string col3 = "";
        string col4 = "";
        string col5 = "";
        string col6 = "";
        string col7 = "";
        string col8 = "";
        string path = Directory.GetCurrentDirectory();

        public Form1()
        {
            InitializeComponent();
        }

        // check first column
        public string checkCol_1()
        {
            if (checkBox1.Checked == true)
            {
                col1 = col1 + "1 ";
            }
            else
            {
                col1 = col1 + "0 ";
            }

            if (checkBox9.Checked == true)
            {
                col1 = col1 + "1 ";
            }
            else
            {
                col1 = col1 + "0 ";
            }

            if (checkBox17.Checked == true)
            {
                col1 = col1 + "1 ";
            }
            else
            {
                col1 = col1 + "0 ";
            }

            if (checkBox25.Checked == true)
            {
                col1 = col1 + "1 ";
            }
            else
            {
                col1 = col1 + "0 ";
            }

            if (checkBox33.Checked == true)
            {
                col1 = col1 + "1 ";
            }
            else
            {
                col1 = col1 + "0 ";
            }

            return col1;
        }

        // check second column
        public string checkCol_2()
        {
            if (checkBox2.Checked == true)
            {
                col2 = col2 + "1 ";
            }
            else
            {
                col2 = col2 + "0 ";
            }

            if (checkBox10.Checked == true)
            {
                col2 = col2 + "1 ";
            }
            else
            {
                col2 = col2 + "0 ";
            }

            if (checkBox18.Checked == true)
            {
                col2 = col2 + "1 ";
            }
            else
            {
                col2 = col2 + "0 ";
            }

            if (checkBox26.Checked == true)
            {
                col2 = col2 + "1 ";
            }
            else
            {
                col2 = col2 + "0 ";
            }

            if (checkBox34.Checked == true)
            {
                col2 = col2 + "1 ";
            }
            else
            {
                col2 = col2 + "0 ";
            }

            return col2;
        }

        // check third column
        public string checkCol_3()
        {
            if (checkBox3.Checked == true)
            {
                col3 = col3 + "1 ";
            }
            else
            {
                col3 = col3 + "0 ";
            }

            if (checkBox11.Checked == true)
            {
                col3 = col3 + "1 ";
            }
            else
            {
                col3 = col3 + "0 ";
            }

            if (checkBox19.Checked == true)
            {
                col3 = col3 + "1 ";
            }
            else
            {
                col3 = col3 + "0 ";
            }

            if (checkBox27.Checked == true)
            {
                col3 = col3 + "1 ";
            }
            else
            {
                col3 = col3 + "0 ";
            }

            if (checkBox35.Checked == true)
            {
                col3 = col3 + "1 ";
            }
            else
            {
                col3 = col3 + "0 ";
            }

            return col3;
        }

        // check fourth column
        public string checkCol_4()
        {
            if (checkBox4.Checked == true)
            {
                col4 = col4 + "1 ";
            }
            else
            {
                col4 = col4 + "0 ";
            }

            if (checkBox12.Checked == true)
            {
                col4 = col4 + "1 ";
            }
            else
            {
                col4 = col4 + "0 ";
            }

            if (checkBox20.Checked == true)
            {
                col4 = col4 + "1 ";
            }
            else
            {
                col4 = col4 + "0 ";
            }

            if (checkBox28.Checked == true)
            {
                col4 = col4 + "1 ";
            }
            else
            {
                col4 = col4 + "0 ";
            }

            if (checkBox36.Checked == true)
            {
                col4 = col4 + "1 ";
            }
            else
            {
                col4 = col4 + "0 ";
            }

            return col4;
        }

        // check fifth column
        public string checkCol_5()
        {
            if (checkBox5.Checked == true)
            {
                col5 = col5 + "1 ";
            }
            else
            {
                col5 = col5 + "0 ";
            }

            if (checkBox13.Checked == true)
            {
                col5 = col5 + "1 ";
            }
            else
            {
                col5 = col5 + "0 ";
            }

            if (checkBox21.Checked == true)
            {
                col5 = col5 + "1 ";
            }
            else
            {
                col5 = col5 + "0 ";
            }

            if (checkBox29.Checked == true)
            {
                col5 = col5 + "1 ";
            }
            else
            {
                col5 = col5 + "0 ";
            }

            if (checkBox37.Checked == true)
            {
                col5 = col5 + "1 ";
            }
            else
            {
                col5 = col5 + "0 ";
            }

            return col5;
        }

        // check sixth column
        public string checkCol_6()
        {
            if (checkBox6.Checked == true)
            {
                col6 = col6 + "1 ";
            }
            else
            {
                col6 = col6 + "0 ";
            }

            if (checkBox14.Checked == true)
            {
                col6 = col6 + "1 ";
            }
            else
            {
                col6 = col6 + "0 ";
            }

            if (checkBox22.Checked == true)
            {
                col6 = col6 + "1 ";
            }
            else
            {
                col6 = col6 + "0 ";
            }

            if (checkBox30.Checked == true)
            {
                col6 = col6 + "1 ";
            }
            else
            {
                col6 = col6 + "0 ";
            }

            if (checkBox38.Checked == true)
            {
                col6 = col6 + "1 ";
            }
            else
            {
                col6 = col6 + "0 ";
            }

            return col6;
        }

        // check seventh column to decide name
        public string checkCol_7()
        {
            if (checkBox7.Checked == true)
            {
                col7 = col7 + "1 ";
            }
            else
            {
                col7 = col7 + "0 ";
            }

            if (checkBox15.Checked == true)
            {
                col7 = col7 + "1 ";
            }
            else
            {
                col7 = col7 + "0 ";
            }

            if (checkBox23.Checked == true)
            {
                col7 = col7 + "1 ";
            }
            else
            {
                col7 = col7 + "0 ";
            }

            if (checkBox31.Checked == true)
            {
                col7 = col7 + "1 ";
            }
            else
            {
                col7 = col7 + "0 ";
            }

            if (checkBox39.Checked == true)
            {
                col7 = col7 + "1 ";
            }
            else
            {
                col7 = col7 + "0 ";
            }

            return col7;
        }

        // check eigth column to decide name
        public string checkCol_8()
        {
            if (checkBox8.Checked == true)
            {
                col8 = col8 + "1 ";
            }
            else
            {
                col8 = col8 + "0 ";
            }

            if (checkBox16.Checked == true)
            {
                col8 = col8 + "1 ";
            }
            else
            {
                col8 = col8 + "0 ";
            }

            if (checkBox24.Checked == true)
            {
                col8 = col8 + "1 ";
            }
            else
            {
                col8 = col8 + "0 ";
            }

            if (checkBox32.Checked == true)
            {
                col8 = col8 + "1 ";
            }
            else
            {
                col8 = col8 + "0 ";
            }

            if (checkBox40.Checked == true)
            {
                col8 = col8 + "1 ";
            }
            else
            {
                col8 = col8 + "0 ";
            }

            return col8;
        }

        // creates name
        public void nameCreate()
        {
            // creates prefix
            /*if(col1[col1.Length-2] == '1')
            {
                if(col1[0] == '1')
                {
                    name = name + "A1_";
                }
                else if (col1[1] == '1')
                {
                    name = name + "B1_";
                }
                else if (col1[2] == '1')
                {
                    name = name + "C1_";
                }
                else if (col1[3] == '1')
                {
                    name = name + "D1_";
                }
                else
                {
                    name = name + "O1_";
                }
            }
            else
            {
                if (col1[0] == '1')
                {
                    name = name + "A0_";
                }
                else if (col1[1] == '1')
                {
                    name = name + "B0_";
                }
                else if (col1[2] == '1')
                {
                    name = name + "C0_";
                }
                else if (col1[3] == '1')
                {
                    name = name + "D0_";
                }
                else
                {
                    name = name + "O0_";
                }
            }

            // genereates inbetween text
            if (col2[0] == '1')
            {
                name = name + "A";
            }
            else if (col2[1] == '1')
            {
                name = name + "B";
            }
            else if (col2[2] == '1')
            {
                name = name + "C";
            }
            else if (col2[3] == '1')
            {
                name = name + "D";
            }
            else
            {
                name = name + "E";
            }

            if (col3[0] == '1')
            {
                name = name + "A";
            }
            else if (col3[1] == '1')
            {
                name = name + "B";
            }
            else if (col3[2] == '1')
            {
                name = name + "C";
            }
            else if (col3[3] == '1')
            {
                name = name + "D";
            }
            else
            {
                name = name + "E";
            }

            if (col4[0] == '1')
            {
                name = name + "A";
            }
            else if (col4[1] == '1')
            {
                name = name + "B";
            }
            else if (col4[2] == '1')
            {
                name = name + "C";
            }
            else if (col4[3] == '1')
            {
                name = name + "D";
            }
            else
            {
                name = name + "E";
            }

            if (col5[0] == '1')
            {
                name = name + "A";
            }
            else if (col5[1] == '1')
            {
                name = name + "B";
            }
            else if (col5[2] == '1')
            {
                name = name + "C";
            }
            else if (col5[3] == '1')
            {
                name = name + "D";
            }
            else
            {
                name = name + "E";
            }

            if (col6[0] == '1')
            {
                name = name + "A";
            }
            else if (col6[1] == '1')
            {
                name = name + "B";
            }
            else if (col6[2] == '1')
            {
                name = name + "C";
            }
            else if (col6[3] == '1')
            {
                name = name + "D";
            }
            else
            {
                name = name + "E";
            }

            if (col7[0] == '1')
            {
                name = name + "A";
            }
            else if (col7[1] == '1')
            {
                name = name + "B";
            }
            else if (col7[2] == '1')
            {
                name = name + "C";
            }
            else if (col7[3] == '1')
            {
                name = name + "D";
            }
            else
            {
                name = name + "E";
            }

            // creates suffix
            if (col8[col8.Length-2] == '1')
            {
                if (col8[0] == '1')
                {
                    name = name + "_A1";
                }
                else if (col8[1] == '1')
                {
                    name = name + "_B1";
                }
                else if (col8[2] == '1')
                {
                    name = name + "_C1";
                }
                else if (col8[3] == '1')
                {
                    name = name + "_D1";
                }
                else
                {
                    name = name + "_O1";
                }
            }
            else
            {
                if (col8[0] == '1')
                {
                    name = name + "_A0";
                }
                else if (col8[1] == '1')
                {
                    name = name + "_B0";
                }
                else if (col8[2] == '1')
                {
                    name = name + "_C0";
                }
                else if (col8[3] == '1')
                {
                    name = name + "_D0";
                }
                else
                {
                    name = name + "_O0";
                }
            }*/

            // gets the number of files in the current bin folder
            System.IO.DirectoryInfo dir = new System.IO.DirectoryInfo(Directory.GetCurrentDirectory());
            int count = dir.GetFiles().Length;
            
            // adds .txt
            name = "_source" + count + ".txt";
        }

        // writes to and creates text file
        public void fileCreate()
        {
            //File.Create(path + name);
            TextWriter tw = new StreamWriter(path + name);

            tw.WriteLine(Reverse(col1));
            tw.WriteLine(Reverse(col2));
            tw.WriteLine(Reverse(col3));
            tw.WriteLine(Reverse(col4));
            tw.WriteLine(Reverse(col5));
            tw.WriteLine(Reverse(col6));
            tw.WriteLine(Reverse(col7));
            tw.WriteLine(Reverse(col8));
            tw.Close();
        }

        // reset all attributes
        public void Reset()
        {
            name = "";
            col1 = "";
            col2 = "";
            col3 = "";
            col4 = "";
            col5 = "";
            col6 = "";
            col7 = "";
            col8 = "";
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Reset();

            checkCol_1();
            checkCol_2();
            checkCol_3();
            checkCol_4();
            checkCol_5();
            checkCol_6();
            checkCol_7();
            checkCol_8();

            nameCreate();
            fileCreate();

            Console.WriteLine("File created as: " + name);
        }

        public static string Reverse(string s)
        {
            char[] charArray = s.ToCharArray();
            Array.Reverse(charArray);
            return new string(charArray);
        }
    }
}
